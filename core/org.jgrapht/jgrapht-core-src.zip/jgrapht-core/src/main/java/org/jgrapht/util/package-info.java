/**
 * Non-graph-specific data structures, algorithms, and utilities used by <b>JGraphT</b>.
 */
package org.jgrapht.util;
