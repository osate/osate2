/**
 * Generators for graphs of various topologies.
 */
package org.jgrapht.generate;
