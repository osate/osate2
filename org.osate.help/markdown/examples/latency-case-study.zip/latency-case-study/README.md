# Latency Analysis Case Study
Paper for this case study can be found at [http://e-archivo.uc3m.es/bitstream/handle/10016/19688/incremental_REACTION_2014.pdf]